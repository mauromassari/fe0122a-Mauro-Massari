
Scrivere un programma che descriva e inizializzi le caratteristiche dei capi di abbigliamento
attraverso il costructor.
Utilizzare i metodi getsaldocapo(per applicare il saldo da sottrarre all acquisto del capo alla cassa)
 e il metodo getacquistocapo(che riporterà il costo totale di tale capo).
Successivamente utilizzi fetch per recuperare i capi dal file Abbigliamento.json,
dove son presenti tutte le caratteristiche dei capi di abbigliamento.

è necessario mostrare in console le caratteristiche dei capi una volta ottenuta la risposta della funzione fetch.
Creare manualmente altre 3 istanze della classe creata precedentemente, scrivendo le caratteristiche dei capi a mano.
(vietato modificare il file Abbigliamento.json)

Dati:

proprietà:

        id:number
        codprod:number
        collezione:string
        capo:string
        modello:number
        quantita:number
        colore:string
        prezzoivaesclusa:number
        prezzoivainclusa:number
        disponibile:string
        saldo:number


        metodi:
        
        getsaldocapo:number
        getacquistocapo:number
